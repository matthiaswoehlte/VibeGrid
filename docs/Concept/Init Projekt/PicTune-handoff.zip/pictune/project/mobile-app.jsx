// PicTune Mobile — Smartphone-first app
// Reuses FX_LIBRARY, MEDIA, INITIAL_CLIPS, TRACKS, TL_CFG, genWaveform from data.jsx
// Reuses Icon from icons.jsx

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "electric"
}/*EDITMODE-END*/;

function StageFigure() {
  return (
    <svg viewBox="0 0 200 320" preserveAspectRatio="xMidYMid meet">
      <ellipse cx="100" cy="80" rx="42" ry="48" fill="rgba(255,255,255,0.06)" />
      <path d="M48 320 L60 180 Q100 150 140 180 L152 320 Z" fill="rgba(255,255,255,0.04)" />
    </svg>
  );
}

function StageContours() {
  return (
    <div className="fx-contour">
      <svg viewBox="0 0 600 380" preserveAspectRatio="none">
        <path d="M220 60 Q300 30 380 60 Q420 130 380 180 Q440 200 470 280 Q485 320 480 360 L120 360 Q115 320 130 280 Q160 200 220 180 Q180 130 220 60 Z" />
        <path d="M250 90 Q300 70 350 90 Q380 140 350 180 Q300 200 250 180 Q220 140 250 90 Z" />
        <path d="M150 280 Q200 240 300 230 Q400 240 450 280 L440 360 L160 360 Z" />
      </svg>
    </div>
  );
}

function StageParticles({ count = 16 }) {
  const dots = React.useMemo(() => {
    let s = 17;
    const r = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    return Array.from({ length: count }).map(() => ({
      left:  4 + r() * 92,
      delay: -r() * 4,
      dx:    (r() - 0.5) * 60,
      size:  2 + r() * 3,
      hue:   r(),
    }));
  }, [count]);
  return (
    <div className="fx-particles">
      {dots.map((d, i) => {
        const color = d.hue < 0.33 ? 'var(--a1)' : d.hue < 0.66 ? 'var(--a2)' : 'var(--a3)';
        return (
          <i key={i} style={{
            left: d.left + '%',
            width: d.size, height: d.size,
            background: color,
            boxShadow: `0 0 8px ${color}`,
            animationDelay: d.delay + 's',
            '--dx': d.dx + 'px',
          }} />
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────
function MiniTimeline({ playhead, setPlayhead, clips, zoom = 16 }) {
  const cfg = TL_CFG;
  const totalBeats = cfg.bars * cfg.beatsPerBar;
  const pxPerBeat = zoom;
  const width = totalBeats * pxPerBeat;
  const waveSamples = React.useMemo(() => genWaveform(totalBeats * 5, 9), [totalBeats]);

  // Build wave path
  const wavePath = React.useMemo(() => {
    const h = 132;
    const mid = h / 2;
    const dx = width / waveSamples.length;
    let p = `M0 ${mid} `;
    waveSamples.forEach((v, i) => { p += `L${(i * dx).toFixed(1)} ${(mid - v * mid * 0.95).toFixed(1)} `; });
    p += `L${width} ${mid} `;
    for (let i = waveSamples.length - 1; i >= 0; i--) {
      p += `L${(i * dx).toFixed(1)} ${(mid + waveSamples[i] * mid * 0.95).toFixed(1)} `;
    }
    return p + 'Z';
  }, [waveSamples, width]);

  // Bar ticks
  const ticks = [];
  for (let bar = 0; bar < cfg.bars; bar++) {
    ticks.push({ x: bar * cfg.beatsPerBar * pxPerBeat, bar: true, l: String(bar + 1).padStart(2,'0') });
    for (let b = 1; b < cfg.beatsPerBar; b++) {
      ticks.push({ x: (bar * cfg.beatsPerBar + b) * pxPerBeat, bar: false });
    }
  }

  const onClick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - r.left + e.currentTarget.scrollLeft;
    // The clickable area is just the inner div; convert
    const inner = e.currentTarget.querySelector('.mini-tl-inner');
    if (!inner) return;
    const rr = inner.getBoundingClientRect();
    const ix = e.clientX - rr.left;
    setPlayhead(Math.max(0, Math.min(totalBeats, ix / pxPerBeat)));
  };

  // Auto-scroll playhead into view
  const scrollRef = React.useRef(null);
  React.useEffect(() => {
    const el = scrollRef.current;
    if (!el) return;
    const phPx = playhead * pxPerBeat;
    const w = el.clientWidth;
    const sl = el.scrollLeft;
    if (phPx < sl + 40 || phPx > sl + w - 60) {
      el.scrollLeft = phPx - w * 0.3;
    }
  }, [playhead, pxPerBeat]);

  // Render track rows (compact, just 5 lanes)
  const trackOrder = TRACKS.map(t => t.id);

  return (
    <div className="mini-tl">
      <div className="mini-tl-head">
        <span className="pill">BPM <b>{cfg.bpm}</b></span>
        <span className="pill">BARS <b>{cfg.bars}</b></span>
        <span className="grow" />
        <span style={{ color: 'var(--a3)' }}>● LIVE</span>
      </div>
      <div className="mini-tl-scroll" ref={scrollRef} onClick={onClick}>
        <div className="mini-tl-inner" style={{ width }}>
          <div className="mini-tl-ruler" style={{ width }}>
            {ticks.map((t, i) => (
              <div key={i} className={`tick ${t.bar ? 'bar' : ''}`} data-l={t.l} style={{ left: t.x }} />
            ))}
          </div>
          <div className="mini-tl-wave" style={{ width, top: 0 }}>
            <svg viewBox={`0 0 ${width} 132`} preserveAspectRatio="none">
              <defs>
                <linearGradient id="mwave-grad" x1="0" x2="0" y1="0" y2="1">
                  <stop offset="0%" stopColor="#a86bff" stopOpacity="0.9" />
                  <stop offset="50%" stopColor="#5a8fff" stopOpacity="0.7" />
                  <stop offset="100%" stopColor="#2ee0d0" stopOpacity="0.4" />
                </linearGradient>
              </defs>
              <path d={wavePath} fill="url(#mwave-grad)" />
            </svg>
          </div>
          <div className="mini-tracks">
            {trackOrder.map((tid) => (
              <div key={tid} className="mini-track">
                {clips.filter(c => c.track === tid).map(c => (
                  <div key={c.id} className="mini-clip"
                    data-kind={c.kind}
                    style={{ left: c.start * pxPerBeat, width: c.length * pxPerBeat - 1 }}>
                    {c.label}
                  </div>
                ))}
              </div>
            ))}
          </div>
          <div className="mini-playhead" style={{ left: playhead * pxPerBeat }} />
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
function TimelinePanel({ playhead, setPlayhead, clips, onClipTap }) {
  return (
    <>
      <MiniTimeline playhead={playhead} setPlayhead={setPlayhead} clips={clips} />
      <div className="tracks-list">
        {TRACKS.map(t => {
          const I = Icon[t.icon];
          const tClips = clips.filter(c => c.track === t.id);
          const active = tClips.some(c => playhead >= c.start && playhead < c.start + c.length);
          return (
            <div key={t.id} className="track-card">
              <span className="ic"><I /></span>
              <div className="info">
                <div className="name">{t.name}</div>
                <div className="meta">{tClips.length} clips · {active ? 'PLAYING' : 'idle'}</div>
              </div>
              <div className="ctrl">
                <button data-on={active ? '1' : '0'} aria-label="Mute"><Icon.bolt /></button>
                <button onClick={() => onClipTap(tClips[0])} aria-label="Edit"><Icon.settings /></button>
              </div>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────
function FxThumb({ kind }) {
  if (kind === 'contour') return (
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 50% 60%, rgba(168,107,255,0.35), transparent 70%)' }}>
      <svg viewBox="0 0 80 50" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
        <path d="M30 8 Q40 4 50 8 Q56 18 50 26 Q60 32 64 44 L16 44 Q20 32 30 26 Q24 18 30 8 Z"
          fill="none" stroke="#a86bff" strokeWidth="1.4"
          style={{ filter: 'drop-shadow(0 0 5px #a86bff)' }} />
      </svg>
    </div>
  );
  if (kind === 'pulse') return (
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(255,95,162,0.4), transparent 60%)' }}>
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: 30, height: 30, transform: 'translate(-50%, -50%)', borderRadius: '50%', background: 'linear-gradient(180deg, #ff5fa2, #ff3aa9)', boxShadow: '0 0 16px #ff5fa2' }} />
      <div style={{ position: 'absolute', left: '50%', top: '50%', width: 50, height: 50, transform: 'translate(-50%, -50%)', borderRadius: '50%', border: '1px solid rgba(255,95,162,0.4)' }} />
    </div>
  );
  if (kind === 'sweep') return (
    <div style={{ position: 'absolute', inset: 0, background: '#0f1428', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', width: '70%', height: '120%', left: '-10%', top: '-10%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(168,107,255,0.55), transparent 70%)', filter: 'blur(14px)' }} />
      <div style={{ position: 'absolute', width: '60%', height: '120%', right: '-5%', top: '20%', borderRadius: '50%', background: 'radial-gradient(circle, rgba(46,224,208,0.5), transparent 70%)', filter: 'blur(16px)' }} />
    </div>
  );
  if (kind === 'particles') return (
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(ellipse at 50% 100%, rgba(168,107,255,0.25), transparent 60%)' }}>
      {[...Array(14)].map((_, i) => {
        const colors = ['#a86bff', '#5a8fff', '#2ee0d0'];
        const c = colors[i % 3];
        return <i key={i} style={{ position: 'absolute', left: ((i * 37) % 100) + '%', top: (20 + (i * 13) % 70) + '%', width: 3, height: 3, borderRadius: '50%', background: c, boxShadow: `0 0 5px ${c}` }} />;
      })}
    </div>
  );
  if (kind === 'glitch') return (
    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #2a4dff 0%, #0f1428 100%)' }}>
      <div style={{ position: 'absolute', top: '30%', left: 0, right: 0, height: 4, background: 'rgba(255,95,162,0.6)', mixBlendMode: 'screen' }} />
      <div style={{ position: 'absolute', top: '60%', left: 0, right: 0, height: 6, background: 'rgba(46,229,255,0.6)', mixBlendMode: 'screen' }} />
    </div>
  );
  if (kind === 'shake') return (
    <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle, rgba(255,95,162,0.3), transparent 70%)' }}>
      <div style={{ position: 'absolute', left: '40%', top: '30%', width: 30, height: 30, borderRadius: 6, background: 'linear-gradient(135deg, #a86bff, #5a8fff)', boxShadow: '5px 0 0 rgba(255,95,162,0.4), -5px 0 0 rgba(46,229,255,0.4)' }} />
    </div>
  );
  if (kind === 'flare') return (
    <div style={{ position: 'absolute', inset: 0, background: '#0f1428', overflow: 'hidden' }}>
      <div style={{ position: 'absolute', top: '20%', left: '-20%', width: '160%', height: 22, background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.8) 50%, transparent 100%)', transform: 'rotate(-15deg)', filter: 'blur(2px)' }} />
      <div style={{ position: 'absolute', top: '60%', left: '20%', width: 20, height: 20, borderRadius: '50%', background: '#fff', filter: 'blur(5px)' }} />
    </div>
  );
  if (kind === 'sparkle') return (
    <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, #1c1633, #0a0f1f)' }}>
      {[...Array(10)].map((_, i) => (
        <div key={i} style={{ position: 'absolute', left: ((i * 23) % 90 + 5) + '%', top: ((i * 31) % 80 + 10) + '%', width: 3, height: 3, background: '#fff', borderRadius: '50%', boxShadow: '0 0 6px #fff' }} />
      ))}
    </div>
  );
  return null;
}

function EffectsPanel({ selectedFx, setSelectedFx, onAdd }) {
  return (
    <>
      <div className="fx-grid">
        {FX_LIBRARY.map(f => (
          <button key={f.id} className="fx-card" data-active={selectedFx === f.id ? '1' : '0'}
                  onClick={() => { setSelectedFx(f.id); onAdd && onAdd(f); }}>
            <div className="fx-thumb"><FxThumb kind={f.id} /></div>
            <div className="fx-meta">
              <div className="fx-name">{f.name}</div>
              <div className="fx-kind">{f.kind} · {f.defaults.sync}</div>
            </div>
          </button>
        ))}
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────
function MediaPanel({ selectedMedia, setSelectedMedia }) {
  return (
    <div className="media-grid">
      <button className="media-tile upload">
        <Icon.upload />
        <span className="l">Drop</span>
      </button>
      <button className="media-tile upload">
        <Icon.link />
        <span className="l">URL</span>
      </button>
      <button className="media-tile upload">
        <Icon.plus />
        <span className="l">Foto</span>
      </button>
      {MEDIA.map(m => (
        <button key={m.id} className="media-tile" data-active={selectedMedia === m.id ? '1' : '0'}
                onClick={() => setSelectedMedia(m.id)}>
          <div className="bg" style={{ background: m.grad }}>
            <div style={{ position: 'absolute', inset: 0, background: 'repeating-linear-gradient(135deg, transparent 0, transparent 6px, rgba(255,255,255,0.04) 6px, rgba(255,255,255,0.04) 7px)' }} />
          </div>
          <div className="label">{m.name.split('.')[0].slice(0,9)}</div>
        </button>
      ))}
    </div>
  );
}

// ─────────────────────────────────────────────────────
function SettingsPanel({ accent, setAccent }) {
  const themes = [
    { id: 'electric', name: 'Electric', colors: 'linear-gradient(135deg, #a86bff, #5a8fff 50%, #2ee0d0)' },
    { id: 'sunset',   name: 'Sunset',   colors: 'linear-gradient(135deg, #ff8a3d, #ff5fa2 50%, #b15aff)' },
    { id: 'acid',     name: 'Acid',     colors: 'linear-gradient(135deg, #b6ff3a, #ff3aa9 50%, #2ee5ff)' },
    { id: 'neon',     name: 'Neon',     colors: 'linear-gradient(135deg, #2ee5ff, #ff3aa9 50%, #b6ff3a)' },
  ];
  return (
    <div style={{ paddingTop: 12 }}>
      <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', marginBottom: 10 }}>Accent</div>
      <div className="theme-grid">
        {themes.map(t => (
          <button key={t.id} className="theme-card" data-on={accent === t.id ? '1' : '0'} onClick={() => setAccent(t.id)}>
            <div className="bg" style={{ background: t.colors }} />
            <span className="name">{t.name}</span>
          </button>
        ))}
      </div>

      <div style={{ fontSize: 10.5, fontWeight: 600, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-muted)', margin: '20px 0 10px' }}>Project</div>
      <div className="menu-item">
        <span className="ic"><Icon.music /></span>
        <div className="info">
          <div className="name">Audio Track</div>
          <div className="sub">drop.mp3 · 128 BPM</div>
        </div>
        <Icon.chevron style={{ transform: 'rotate(-90deg)', color: 'var(--text-muted)' }} />
      </div>
      <div className="menu-item">
        <span className="ic"><Icon.magnet /></span>
        <div className="info">
          <div className="name">Beat Snap</div>
          <div className="sub">1/4 Beat (current)</div>
        </div>
        <Icon.chevron style={{ transform: 'rotate(-90deg)', color: 'var(--text-muted)' }} />
      </div>
      <div className="menu-item">
        <span className="ic"><Icon.download /></span>
        <div className="info">
          <div className="name">Export</div>
          <div className="sub">MP4 · 1080p · 60fps</div>
        </div>
        <Icon.chevron style={{ transform: 'rotate(-90deg)', color: 'var(--text-muted)' }} />
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────
function InspectorSheet({ open, fx, params, setParams, onClose }) {
  if (!fx) return null;
  const Iicon = Icon[fx.id === 'contour' ? 'bolt' : fx.id === 'sweep' ? 'circles' : fx.id === 'particles' ? 'particles' : fx.id === 'pulse' ? 'pulse' : 'sparkle'];
  return (
    <>
      <div className="sheet-backdrop" data-open={open ? '1' : '0'} onClick={onClose} />
      <div className="sheet" data-open={open ? '1' : '0'}>
        <div className="grab" />
        <div className="sheet-h">
          <span className="ic"><Iicon /></span>
          <div className="info">
            <div className="name">{fx.name}</div>
            <div className="sub">{fx.kind} · {fx.defaults.sync}-sync</div>
          </div>
          <button className="tbtn" onClick={onClose} aria-label="Close" style={{ width: 36, height: 36 }}>✕</button>
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Trigger</span></div>
          <div className="seg">
            {['½ Bar', 'Beat', 'Bar', '2 Bar'].map((l, i) => (
              <button key={l} data-on={i === 1 ? '1' : '0'}>{l}</button>
            ))}
          </div>
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Intensity</span><span className="v">{params.intensity}%</span></div>
          <input type="range" className="range" min="0" max="100" value={params.intensity}
                 onChange={(e) => setParams({ ...params, intensity: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Stroke</span><span className="v">{params.stroke}px</span></div>
          <input type="range" className="range" min="0.5" max="6" step="0.5" value={params.stroke}
                 onChange={(e) => setParams({ ...params, stroke: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Glow</span><span className="v">{params.glow}px</span></div>
          <input type="range" className="range" min="0" max="40" value={params.glow}
                 onChange={(e) => setParams({ ...params, glow: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Decay</span><span className="v">{params.decay}ms</span></div>
          <input type="range" className="range" min="40" max="800" step="20" value={params.decay}
                 onChange={(e) => setParams({ ...params, decay: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="lbl"><span>Color</span></div>
          <div className="color-strip" role="radiogroup">
            {[
              { c: '#a86bff', k: 'a1' },
              { c: '#5a8fff', k: 'a2' },
              { c: '#2ee0d0', k: 'a3' },
              { c: '#ff5fa2', k: 'a4' },
              { c: '#b6ff3a', k: 'a5' },
            ].map(s => (
              <button key={s.k} className="color-dot"
                style={{ background: s.c, color: s.c }}
                data-on={params.color === s.k ? '1' : '0'}
                onClick={() => setParams({ ...params, color: s.k })} />
            ))}
          </div>
        </div>

        <div className="actions">
          <button className="btn ghost"><Icon.scissors /> Slice</button>
          <button className="btn primary"><Icon.sparkle /> Auto-paint</button>
        </div>
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────
function beatsToTime(beats, bpm) {
  const ms = (beats * 60000) / bpm;
  const total = ms / 1000;
  const m = Math.floor(total / 60);
  const s = Math.floor(total % 60);
  const cs = Math.floor((total * 100) % 100);
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  React.useEffect(() => {
    document.documentElement.dataset.accent = t.accent;
  }, [t]);

  const [playing, setPlaying] = React.useState(true);
  const [playhead, setPlayhead] = React.useState(20);
  const totalBeats = TL_CFG.bars * TL_CFG.beatsPerBar;

  React.useEffect(() => {
    if (!playing) return undefined;
    const beatMs = 60000 / TL_CFG.bpm;
    let last = performance.now();
    let raf;
    const tick = (now) => {
      const dt = now - last; last = now;
      setPlayhead((p) => {
        const next = p + (dt / beatMs);
        return next >= totalBeats ? 0 : next;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, totalBeats]);

  const [tab, setTab] = React.useState('timeline');
  const [selectedMedia, setSelectedMedia] = React.useState('m1');
  const [selectedFx, setSelectedFx] = React.useState('contour');
  const [insp, setInsp] = React.useState({ open: false, fxId: 'contour' });
  const [params, setParams] = React.useState({ intensity: 78, stroke: 1.4, glow: 8, decay: 240, color: 'a3', easing: 'flash' });

  const activeFx = React.useMemo(() => {
    const r = { contour: false, sweep: false, pulse: false, particles: false };
    INITIAL_CLIPS.forEach(c => {
      if (playhead >= c.start && playhead < c.start + c.length) {
        if (c.kind in r) r[c.kind] = true;
      }
    });
    return r;
  }, [playhead]);

  const currentMedia = (() => {
    let active = 'portrait_01';
    INITIAL_CLIPS.filter(c => c.track === 'image').forEach(c => {
      if (playhead >= c.start && playhead < c.start + c.length) active = c.label;
    });
    return active;
  })();

  const currentBar = Math.floor(playhead / TL_CFG.beatsPerBar) + 1;
  const currentBeat = Math.floor(playhead % TL_CFG.beatsPerBar) + 1;
  const tc = beatsToTime(playhead, TL_CFG.bpm);
  const tcTotal = beatsToTime(totalBeats, TL_CFG.bpm);

  const openInspector = (clipOrFx) => {
    const fxId = clipOrFx?.kind && clipOrFx.kind !== 'image' ? clipOrFx.kind : (clipOrFx?.id || selectedFx);
    setInsp({ open: true, fxId });
  };
  const currentFx = FX_LIBRARY.find(f => f.id === insp.fxId) || FX_LIBRARY[0];

  return (
    <div className="phone">
      <div className="status-bar">
        <span>9:41</span>
        <span className="icons" aria-hidden="true">
          <svg width="18" height="11" viewBox="0 0 19 12" fill="#fff"><rect x="0" y="7.5" width="3.2" height="4.5" rx="0.7"/><rect x="4.8" y="5" width="3.2" height="7" rx="0.7"/><rect x="9.6" y="2.5" width="3.2" height="9.5" rx="0.7"/><rect x="14.4" y="0" width="3.2" height="12" rx="0.7"/></svg>
          <svg width="16" height="11" viewBox="0 0 17 12" fill="#fff"><path d="M8.5 3.2C10.8 3.2 12.9 4.1 14.4 5.6L15.5 4.5C13.7 2.7 11.2 1.5 8.5 1.5C5.8 1.5 3.3 2.7 1.5 4.5L2.6 5.6C4.1 4.1 6.2 3.2 8.5 3.2Z"/><path d="M8.5 6.8C9.9 6.8 11.1 7.3 12 8.2L13.1 7.1C11.8 5.9 10.2 5.1 8.5 5.1C6.8 5.1 5.2 5.9 3.9 7.1L5 8.2C5.9 7.3 7.1 6.8 8.5 6.8Z"/><circle cx="8.5" cy="10.5" r="1.5"/></svg>
          <svg width="26" height="12" viewBox="0 0 27 13"><rect x="0.5" y="0.5" width="23" height="12" rx="3.5" stroke="#fff" strokeOpacity="0.4" fill="none"/><rect x="2" y="2" width="20" height="9" rx="2" fill="#fff"/></svg>
        </span>
      </div>

      <header className="appbar">
        <span className="brand-mark" />
        <div className="proj">
          <div className="title">Midnight Drop</div>
          <div className="sub">VIBEGRID · v0.4 · BAR {String(currentBar).padStart(2,'0')}/{TL_CFG.bars}</div>
        </div>
        <button className="iconbtn" aria-label="Share"><Icon.share /></button>
        <button className="iconbtn" aria-label="Settings" onClick={() => setTab('settings')}><Icon.settings /></button>
      </header>

      <div className="stage-section">
        <div
          className="stage"
          style={{ '--bpm': TL_CFG.bpm }}
          data-pulse={playing && activeFx.pulse ? '1' : '0'}
          data-fx-contour={playing && activeFx.contour ? '1' : '0'}
          data-fx-sweep={playing && activeFx.sweep ? '1' : '0'}
          data-fx-particles={playing && activeFx.particles ? '1' : '0'}
          data-fx-pulse={playing && activeFx.pulse ? '1' : '0'}
        >
          <div className="photo">
            <div className="photo-figure"><StageFigure /></div>
            <div className="photo-stripes" />
          </div>
          <div className="fx-flash" />
          <StageContours />
          <div className="fx-sweep">
            <div className="orb a" />
            <div className="orb b" />
            <div className="orb c" />
          </div>
          <StageParticles count={18} />

          <div className="stage-chip tl">
            <span className="dot" />
            {currentMedia}
          </div>
          <div className="stage-chip tr">
            {String(currentBar).padStart(2,'0')}.{currentBeat}
          </div>
          <div className="stage-chip br">
            {Object.entries(activeFx).filter(([k, v]) => v).map(([k]) => k.toUpperCase()).join(' · ') || 'IDLE'}
          </div>
        </div>
      </div>

      <div className="transport">
        <button className="tbtn" aria-label="Skip back"><Icon.skipBack /></button>
        <button className="tbtn play" onClick={() => setPlaying(!playing)} aria-label={playing ? 'Pause' : 'Play'}>
          {playing ? <Icon.pause /> : <Icon.play />}
        </button>
        <button className="tbtn" aria-label="Skip forward"><Icon.skipFwd /></button>
        <div className="tc">
          <div className="time">
            <span>{tc}</span>
            <span className="total">/ {tcTotal}</span>
          </div>
          <div className="sub">
            <span className="a-c">{TL_CFG.bpm} BPM</span> · 4/4 · BAR {String(currentBar).padStart(2,'0')}
          </div>
        </div>
      </div>

      <div className="tabs">
        <button className="tab" data-on={tab === 'timeline' ? '1' : '0'} onClick={() => setTab('timeline')}>
          <Icon.layers /> Timeline <span className="count">{INITIAL_CLIPS.length}</span>
        </button>
        <button className="tab" data-on={tab === 'effects' ? '1' : '0'} onClick={() => setTab('effects')}>
          <Icon.sparkle /> Effekte <span className="count">{FX_LIBRARY.length}</span>
        </button>
        <button className="tab" data-on={tab === 'media' ? '1' : '0'} onClick={() => setTab('media')}>
          <Icon.image /> Media <span className="count">{MEDIA.length}</span>
        </button>
        <button className="tab" data-on={tab === 'settings' ? '1' : '0'} onClick={() => setTab('settings')}>
          <Icon.settings />
        </button>
      </div>

      <div className="panel">
        {tab === 'timeline' && <TimelinePanel playhead={playhead} setPlayhead={setPlayhead} clips={INITIAL_CLIPS} onClipTap={openInspector} />}
        {tab === 'effects'  && <EffectsPanel selectedFx={selectedFx} setSelectedFx={setSelectedFx} onAdd={(fx) => openInspector(fx)} />}
        {tab === 'media'    && <MediaPanel selectedMedia={selectedMedia} setSelectedMedia={setSelectedMedia} />}
        {tab === 'settings' && <SettingsPanel accent={t.accent} setAccent={(v) => setTweak('accent', v)} />}
      </div>

      {/* Floating action buttons */}
      <div className="fab">
        <button aria-label="Cut at playhead"><Icon.scissors /></button>
        <button className="primary" aria-label="Add fx" onClick={() => setTab('effects')}><Icon.plus /></button>
      </div>

      <InspectorSheet
        open={insp.open}
        fx={currentFx}
        params={params} setParams={setParams}
        onClose={() => setInsp({ ...insp, open: false })}
      />

      <TweaksPanel title="VibeGrid Mobile">
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
          options={[
            ['#a86bff', '#5a8fff', '#2ee0d0'],
            ['#ff8a3d', '#ff5fa2', '#b15aff'],
            ['#b6ff3a', '#ff3aa9', '#2ee5ff'],
            ['#2ee5ff', '#ff3aa9', '#b6ff3a'],
          ]}
          onChange={(v) => {
            const map = {
              '["#a86bff","#5a8fff","#2ee0d0"]': 'electric',
              '["#ff8a3d","#ff5fa2","#b15aff"]': 'sunset',
              '["#b6ff3a","#ff3aa9","#2ee5ff"]': 'acid',
              '["#2ee5ff","#ff3aa9","#b6ff3a"]': 'neon',
            };
            setTweak('accent', map[JSON.stringify(v)] || 'electric');
          }} />
      </TweaksPanel>
    </div>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
