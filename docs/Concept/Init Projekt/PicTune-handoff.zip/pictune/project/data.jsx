// PicTune — shared data model (effects, media, clips)
// Loaded BEFORE other component files. Exports onto window.

const FX_LIBRARY = [
  { id: 'contour',   name: 'Kontur-Blitz',   kind: 'Contour',   desc: 'Edge-Detection',  defaults: { intensity: 78, sync: 'beat', easing: 'flash' } },
  { id: 'pulse',     name: 'Beat-Pulse',     kind: 'Pulse',     desc: 'Scale + Vignette', defaults: { intensity: 45, sync: 'beat', easing: 'snap'  } },
  { id: 'sweep',     name: 'Color-Sweep',    kind: 'Sweep',     desc: 'Transparente Kreise', defaults: { intensity: 70, sync: 'bar',  easing: 'glide' } },
  { id: 'particles', name: 'Particles',      kind: 'Particle',  desc: 'Sparks Rising',   defaults: { intensity: 55, sync: 'beat', easing: 'linear' } },
  { id: 'glitch',    name: 'Beat-Glitch',    kind: 'Glitch',    desc: 'RGB Split',       defaults: { intensity: 35, sync: 'beat', easing: 'snap'  } },
  { id: 'shake',     name: 'Camera-Shake',   kind: 'Pulse',     desc: 'Drop-Punch',      defaults: { intensity: 60, sync: 'beat', easing: 'snap'  } },
  { id: 'flare',     name: 'Light-Flare',    kind: 'Sweep',     desc: 'Streak Pass',     defaults: { intensity: 50, sync: 'bar',  easing: 'glide' } },
  { id: 'sparkle',   name: 'Sparkle',        kind: 'Particle',  desc: 'Twinkle Stars',   defaults: { intensity: 40, sync: 'bar',  easing: 'fade'  } },
];

// Media — visualized by colorful gradient swatches.
const MEDIA = [
  { id: 'm1', name: 'portrait_01.jpg', grad: 'linear-gradient(135deg, #6b3aff 0%, #2a4dff 50%, #1f8aff 100%)' },
  { id: 'm2', name: 'studio_neon.jpg', grad: 'linear-gradient(135deg, #ff3aa9 0%, #b15aff 60%, #5a8fff 100%)' },
  { id: 'm3', name: 'live_band.png',   grad: 'linear-gradient(135deg, #ff8a3d 0%, #ff5fa2 60%, #a86bff 100%)' },
  { id: 'm4', name: 'city_lights.jpg', grad: 'linear-gradient(135deg, #2ee0d0 0%, #5a8fff 60%, #a86bff 100%)' },
  { id: 'm5', name: 'silhouette.png',  grad: 'linear-gradient(135deg, #0a0f1f 0%, #1c1633 50%, #6b3aff 100%)' },
  { id: 'm6', name: 'crowd_lit.jpg',   grad: 'linear-gradient(135deg, #ff5fa2 0%, #ff3aa9 40%, #2ee5ff 100%)' },
];

// Timeline configuration — 1 bar = 4 beats. 128 BPM.
const TL_CFG = {
  bpm: 128,
  beatsPerBar: 4,
  bars: 16,
  pxPerBeat: 48,     // base zoom
  trackHeight: 44,
};

// Initial clips — a beat-aligned mini-arrangement.
const INITIAL_CLIPS = [
  // image track
  { id: 'c1', track: 'image', kind: 'image', start: 0,  length: 16, color: '#2ee0d0', label: 'portrait_01' },
  { id: 'c2', track: 'image', kind: 'image', start: 16, length: 16, color: '#2ee0d0', label: 'studio_neon' },
  { id: 'c3', track: 'image', kind: 'image', start: 32, length: 16, color: '#2ee0d0', label: 'live_band' },
  { id: 'c4', track: 'image', kind: 'image', start: 48, length: 16, color: '#2ee0d0', label: 'silhouette' },
  // contour track
  { id: 'c5', track: 'contour', kind: 'contour', start: 4,  length: 4, label: 'kontur·a' },
  { id: 'c6', track: 'contour', kind: 'contour', start: 12, length: 4, label: 'kontur·b' },
  { id: 'c7', track: 'contour', kind: 'contour', start: 20, length: 8, label: 'kontur·c' },
  { id: 'c8', track: 'contour', kind: 'contour', start: 40, length: 4, label: 'kontur·d' },
  { id: 'c9', track: 'contour', kind: 'contour', start: 48, length: 6, label: 'kontur·e' },
  // sweep track
  { id: 'c10', track: 'sweep', kind: 'sweep', start: 0,  length: 16, label: 'sweep·intro' },
  { id: 'c11', track: 'sweep', kind: 'sweep', start: 32, length: 16, label: 'sweep·drop' },
  // pulse track
  { id: 'c12', track: 'pulse', kind: 'pulse', start: 16, length: 16, label: 'pulse·verse' },
  { id: 'c13', track: 'pulse', kind: 'pulse', start: 48, length: 16, label: 'pulse·outro' },
  // particles
  { id: 'c14', track: 'particles', kind: 'particles', start: 24, length: 8, label: 'sparks' },
  { id: 'c15', track: 'particles', kind: 'particles', start: 56, length: 8, label: 'sparks·b' },
];

const TRACKS = [
  { id: 'image',     name: 'Image',     icon: 'image',     activeFx: 'image' },
  { id: 'contour',   name: 'Kontur',    icon: 'bolt',      activeFx: 'contour' },
  { id: 'sweep',     name: 'Sweep',     icon: 'circles',   activeFx: 'sweep' },
  { id: 'pulse',     name: 'Pulse',     icon: 'pulse',     activeFx: 'pulse' },
  { id: 'particles', name: 'Particles', icon: 'particles', activeFx: 'particles' },
];

// Deterministic pseudo-random waveform for the music timeline.
function genWaveform(samples = 240, seed = 7) {
  const out = [];
  let s = seed;
  const rand = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  for (let i = 0; i < samples; i++) {
    const beat = i % 4 === 0 ? 0.95 : 0.5;
    const drop = i > samples * 0.5 && i < samples * 0.55 ? 0.15 : 1;
    const rise = Math.sin((i / samples) * Math.PI * 2) * 0.3 + 0.7;
    const noise = 0.4 + rand() * 0.6;
    out.push(Math.min(1, beat * noise * rise * drop));
  }
  return out;
}

Object.assign(window, { FX_LIBRARY, MEDIA, TL_CFG, INITIAL_CLIPS, TRACKS, genWaveform });
