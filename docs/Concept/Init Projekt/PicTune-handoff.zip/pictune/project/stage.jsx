// PicTune — Stage component
// The preview surface. Renders the demo "photo" + live CSS animations.

function StageFigure() {
  // Abstract "subject" — only simple primitives (ellipses + paths).
  // Three contour paths trace the figure & flash on beat.
  return (
    <svg viewBox="0 0 200 320" preserveAspectRatio="xMidYMid meet">
      {/* head halo (filled) */}
      <ellipse cx="100" cy="80" rx="42" ry="48" fill="rgba(255,255,255,0.06)" />
      {/* body trapezoid (filled, soft) */}
      <path d="M48 320 L60 180 Q100 150 140 180 L152 320 Z" fill="rgba(255,255,255,0.04)" />
    </svg>
  );
}

function StageContours() {
  // Three traced silhouette contours that animate independently.
  return (
    <div className="fx-contour">
      <svg viewBox="0 0 600 380" preserveAspectRatio="none">
        {/* head + shoulders silhouette */}
        <path d="M220 60 Q300 30 380 60 Q420 130 380 180 Q440 200 470 280 Q485 320 480 360 L120 360 Q115 320 130 280 Q160 200 220 180 Q180 130 220 60 Z" />
        {/* inner head outline */}
        <path d="M250 90 Q300 70 350 90 Q380 140 350 180 Q300 200 250 180 Q220 140 250 90 Z" />
        {/* shoulder/torso accent */}
        <path d="M150 280 Q200 240 300 230 Q400 240 450 280 L440 360 L160 360 Z" />
      </svg>
    </div>
  );
}

function StageSweep() {
  return (
    <div className="fx-sweep">
      <div className="orb a" />
      <div className="orb b" />
      <div className="orb c" />
    </div>
  );
}

function StageParticles({ count = 18 }) {
  // Pre-compute positions/delays so they don't change on every render
  // (otherwise the animation restarts on each tweak).
  const dots = React.useMemo(() => {
    let s = 13;
    const r = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
    return Array.from({ length: count }).map(() => ({
      left:  4 + r() * 92,
      delay: -r() * 4,
      dx:    (r() - 0.5) * 80,
      size:  2 + r() * 3,
      hue:   r(),
    }));
  }, [count]);
  return (
    <div className="fx-particles">
      {dots.map((d, i) => {
        const color = d.hue < 0.33 ? 'var(--a1)' : d.hue < 0.66 ? 'var(--a2)' : 'var(--a3)';
        return (
          <i key={i}
             style={{
               left: d.left + '%',
               width: d.size, height: d.size,
               background: color,
               boxShadow: `0 0 calc(8px * var(--glow-mult, 1)) ${color}`,
               animationDelay: d.delay + 's',
               '--dx': d.dx + 'px',
             }} />
        );
      })}
    </div>
  );
}

function Stage({ playing, bpm, activeFx, mediaName, currentBar, currentBeat }) {
  return (
    <div className="stage-wrap">
      <div className="stage-toolbar">
        <div className="stage-chip">
          <span className="dot" />
          <span>{mediaName || 'no media'}</span>
        </div>
        <div style={{ display: 'flex', gap: 8 }}>
          <div className="stage-chip" title="Current bar.beat">
            BAR <b style={{ color: 'var(--text)' }}>{String(currentBar).padStart(2,'0')}</b> · BEAT <b style={{ color: 'var(--text)' }}>{currentBeat}</b>
          </div>
          <div className="stage-chip">
            <Icon.fitScreen /> 100%
          </div>
        </div>
      </div>

      <div
        className="stage"
        style={{ '--bpm': bpm }}
        data-pulse={playing && activeFx.pulse ? '1' : '0'}
        data-fx-contour={playing && activeFx.contour ? '1' : '0'}
        data-fx-sweep={playing && activeFx.sweep ? '1' : '0'}
        data-fx-particles={playing && activeFx.particles ? '1' : '0'}
        data-fx-pulse={playing && activeFx.pulse ? '1' : '0'}
      >
        {/* Backdrop "image" */}
        <div className="photo">
          <div className="photo-figure">
            <StageFigure />
          </div>
          <div className="photo-stripes" />
        </div>

        {/* Effect layers, all positioned absolute */}
        <div className="fx-flash" />
        <StageContours />
        <StageSweep />
        <StageParticles count={20} />

        <div className="photo-label">[ DEMO · {mediaName || 'portrait_01'} ]</div>
      </div>
    </div>
  );
}

window.Stage = Stage;
