// PicTune — Timeline (beat-grid + waveform + clips + playhead)

function Waveform({ samples, width, height }) {
  // Build top + mirror bottom path.
  const dx = width / samples.length;
  const mid = height / 2;
  let top = `M0 ${mid} `;
  samples.forEach((v, i) => { top += `L${(i * dx).toFixed(1)} ${(mid - v * mid * 0.95).toFixed(1)} `; });
  top += `L${width} ${mid} `;
  // Mirror back
  for (let i = samples.length - 1; i >= 0; i--) {
    top += `L${(i * dx).toFixed(1)} ${(mid + samples[i] * mid * 0.95).toFixed(1)} `;
  }
  top += 'Z';
  return (
    <div className="tl-waveform">
      <svg viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none">
        <defs>
          <linearGradient id="wave-grad" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%"   stopColor="#a86bff" stopOpacity="0.9" />
            <stop offset="50%"  stopColor="#5a8fff" stopOpacity="0.7" />
            <stop offset="100%" stopColor="#2ee0d0" stopOpacity="0.4" />
          </linearGradient>
        </defs>
        <path d={top} />
      </svg>
    </div>
  );
}

function Ruler({ bars, pxPerBeat, beatsPerBar }) {
  const ticks = [];
  for (let bar = 0; bar < bars; bar++) {
    ticks.push({ x: bar * beatsPerBar * pxPerBeat, kind: 'bar', label: String(bar + 1).padStart(2, '0') });
    for (let b = 1; b < beatsPerBar; b++) {
      ticks.push({ x: (bar * beatsPerBar + b) * pxPerBeat, kind: 'beat' });
    }
  }
  const width = bars * beatsPerBar * pxPerBeat;
  return (
    <div className="tl-ruler" style={{ width }}>
      {ticks.map((t, i) => (
        <div key={i}
          className={`tick ${t.kind}`}
          data-l={t.label}
          style={{ left: t.x }} />
      ))}
    </div>
  );
}

function BeatGrid({ bars, beatsPerBar, pxPerBeat }) {
  const lines = [];
  for (let bar = 0; bar < bars; bar++) {
    for (let b = 0; b < beatsPerBar; b++) {
      const x = (bar * beatsPerBar + b) * pxPerBeat;
      lines.push({ x, bar: b === 0 });
    }
  }
  return (
    <>
      {lines.map((l, i) => (
        <div key={i}
          className={`tl-beat ${l.bar ? 'bar' : ''}`}
          style={{ left: l.x }} />
      ))}
    </>
  );
}

function Clip({ clip, pxPerBeat, active, onClick }) {
  const left = clip.start * pxPerBeat;
  const width = clip.length * pxPerBeat - 2;
  return (
    <div className="clip"
      data-kind={clip.kind}
      data-active={active ? '1' : '0'}
      style={{ left, width }}
      onClick={(e) => { e.stopPropagation(); onClick && onClick(clip); }}>
      <span className="clip-handle l" />
      <span className="clip-label">{clip.label}</span>
      <span className="clip-handle r" />
    </div>
  );
}

function Timeline({ playhead, setPlayhead, clips, selectedClip, setSelectedClip, zoom }) {
  const cfg = TL_CFG;
  const pxPerBeat = cfg.pxPerBeat * zoom;
  const totalBeats = cfg.bars * cfg.beatsPerBar;
  const trackWidth = totalBeats * pxPerBeat;

  const waveSamples = React.useMemo(() => genWaveform(totalBeats * 6, 7), [totalBeats]);

  const onTrackClick = (e) => {
    const r = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - r.left + e.currentTarget.scrollLeft;
    setPlayhead(Math.max(0, Math.min(totalBeats, x / pxPerBeat)));
  };

  return (
    <section className="tl">
      <div className="tl-toolbar">
        <div className="tl-tool"><span className="lbl">BPM</span><span className="v">{cfg.bpm}</span></div>
        <div className="tl-tool bars"><span className="lbl">BARS</span><span className="v">{cfg.bars}</span></div>
        <div className="tl-tool snap"><Icon.magnet /><span className="v">1/4 Beat</span></div>
        <div className="tl-tool"><Icon.music /><span className="v">drop.mp3</span></div>
        <div className="tl-zoom">
          <button className="zbtn" title="Zoom out"><Icon.zoomOut /></button>
          <button className="zbtn" title="Fit"><Icon.fitScreen /></button>
          <button className="zbtn" title="Zoom in"><Icon.zoomIn /></button>
        </div>
      </div>

      <div className="tl-body">
        {/* Track labels (left col) */}
        <div className="tl-labels">
          {/* Ruler-row spacer to align with main ruler */}
          <div style={{ height: 26, borderBottom: '1px solid var(--border)' }} />
          {TRACKS.map(t => {
            const I = Icon[t.icon];
            return (
              <div key={t.id} className="tl-track-row">
                <span className="icon"><I /></span>
                <span className="name">{t.name}</span>
                <span className="mute" data-on="0" title="Mute">M</span>
              </div>
            );
          })}
        </div>

        {/* Tracks area (right col) — scrollable horizontally */}
        <div className="tl-tracks" onClick={onTrackClick}>
          <div style={{ position: 'relative', width: trackWidth, minWidth: '100%' }}>
            <Ruler bars={cfg.bars} pxPerBeat={pxPerBeat} beatsPerBar={cfg.beatsPerBar} />
            <Waveform samples={waveSamples} width={trackWidth} height={60} />

            {TRACKS.map(t => (
              <div key={t.id} className="tl-track-body" style={{ width: trackWidth }}>
                <BeatGrid bars={cfg.bars} beatsPerBar={cfg.beatsPerBar} pxPerBeat={pxPerBeat} />
                {clips.filter(c => c.track === t.id).map(c => (
                  <Clip key={c.id} clip={c} pxPerBeat={pxPerBeat}
                    active={selectedClip === c.id}
                    onClick={(cl) => setSelectedClip(cl.id)} />
                ))}
              </div>
            ))}

            <div className="tl-playhead" style={{ left: playhead * pxPerBeat }} />
          </div>
        </div>
      </div>
    </section>
  );
}

window.Timeline = Timeline;
