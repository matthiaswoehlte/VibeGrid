// PicTune — Main App
// Composes top bar + panels + stage + timeline.
// Owns global state: playback, active clip, fx params, tweaks.

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accent": "electric",
  "font": "grotesk",
  "density": "regular",
  "timeline": "regular",
  "style": "balanced"
}/*EDITMODE-END*/;

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply tweak data-* attributes to <html>.
  React.useEffect(() => {
    const r = document.documentElement;
    r.dataset.accent = t.accent;
    r.dataset.font = t.font;
    r.dataset.density = t.density;
    r.dataset.timeline = t.timeline;
    r.dataset.style = t.style;
  }, [t]);

  // ── Playback ─────────────────────────────
  const [playing, setPlaying] = React.useState(true);
  const [playhead, setPlayhead] = React.useState(8); // in beats
  const totalBeats = TL_CFG.bars * TL_CFG.beatsPerBar;

  React.useEffect(() => {
    if (!playing) return undefined;
    const beatMs = 60000 / TL_CFG.bpm;
    let last = performance.now();
    let raf;
    const tick = (now) => {
      const dt = now - last; last = now;
      setPlayhead((p) => {
        const next = p + (dt / beatMs);
        return next >= totalBeats ? 0 : next;
      });
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [playing, totalBeats]);

  // ── Selection ─────────────────────────────
  const [leftTab, setLeftTab] = React.useState('media');
  const [selectedMedia, setSelectedMedia] = React.useState('m1');
  const [selectedFx, setSelectedFx] = React.useState('contour');
  const [selectedClip, setSelectedClip] = React.useState('c5');

  const currentClip = INITIAL_CLIPS.find(c => c.id === selectedClip);
  const currentFx = currentClip
    ? FX_LIBRARY.find(f => f.id === currentClip.kind) || FX_LIBRARY.find(f => f.id === selectedFx)
    : FX_LIBRARY.find(f => f.id === selectedFx);

  // ── Fx params (for inspector) ───────────────
  const [params, setParams] = React.useState({
    intensity: 78, stroke: 1.2, glow: 8, decay: 240,
    color: 'a3', easing: 'flash',
  });

  // ── Live fx flags (computed from clips overlapping playhead) ──
  const activeFx = React.useMemo(() => {
    const r = { contour: false, sweep: false, pulse: false, particles: false };
    INITIAL_CLIPS.forEach(c => {
      if (playhead >= c.start && playhead < c.start + c.length) {
        if (c.kind in r) r[c.kind] = true;
      }
    });
    return r;
  }, [playhead]);

  const currentMedia = (() => {
    let active = null;
    INITIAL_CLIPS.filter(c => c.track === 'image').forEach(c => {
      if (playhead >= c.start && playhead < c.start + c.length) active = c.label + '.jpg';
    });
    return active;
  })();

  // ── Bar / beat readout ─────────────────────
  const currentBar = Math.floor(playhead / TL_CFG.beatsPerBar) + 1;
  const currentBeat = Math.floor(playhead % TL_CFG.beatsPerBar) + 1;
  const time = beatsToTime(playhead, TL_CFG.bpm);
  const totalTime = beatsToTime(totalBeats, TL_CFG.bpm);

  // ── Mobile sheet ───────────────────────────
  const [mobSheet, setMobSheet] = React.useState(null);

  // ── Zoom ───────────────────────────────────
  const [zoom] = React.useState(1);

  return (
    <div className="app">
      {/* TOP BAR */}
      <header className="topbar">
        <div className="brand">
          <span className="brand-mark" />
          <span>VibeGrid</span>
        </div>
        <span className="divider" />
        <button className="project-name">
          <Icon.music />
          <b>Midnight Drop</b>
          <span style={{ color: 'var(--text-faint)' }}>·</span>
          <span>v0.4</span>
          <Icon.chevron />
        </button>

        <div className="transport">
          <button className="tbtn" title="Back to start"><Icon.skipBack /></button>
          <button className="tbtn play" data-playing={playing ? '1' : '0'}
                  onClick={() => setPlaying(!playing)}
                  title={playing ? 'Pause' : 'Play'}>
            {playing ? <Icon.pause /> : <Icon.play />}
          </button>
          <button className="tbtn" title="Forward"><Icon.skipFwd /></button>
          <div className="timecode">
            <span>{time}</span>
            <span className="total"> / {totalTime}</span>
          </div>
          <div className="bpm-badge">
            <span className="bpm-dot" /> {TL_CFG.bpm} BPM
          </div>
        </div>

        <div className="top-actions">
          <button className="btn ghost" title="Share"><Icon.share /><span className="label">Share</span></button>
          <button className="btn primary" title="Export"><Icon.download /><span className="label">Export</span></button>
        </div>
      </header>

      {/* MAIN */}
      <div className="main">
        <LeftPanel
          tab={leftTab} setTab={setLeftTab}
          selectedMedia={selectedMedia} setSelectedMedia={setSelectedMedia}
          selectedFx={selectedFx} setSelectedFx={setSelectedFx}
        />

        <div className="workspace">
          <Stage
            playing={playing}
            bpm={TL_CFG.bpm}
            activeFx={activeFx}
            mediaName={currentMedia}
            currentBar={currentBar}
            currentBeat={currentBeat}
          />
          <Timeline
            playhead={playhead}
            setPlayhead={setPlayhead}
            clips={INITIAL_CLIPS}
            selectedClip={selectedClip}
            setSelectedClip={setSelectedClip}
            zoom={zoom}
          />
        </div>

        <Inspector
          selectedClip={currentClip}
          fx={currentFx}
          params={params}
          setParams={setParams}
        />
      </div>

      {/* MOBILE TAB BAR */}
      <nav className="mob-tabs">
        <button className="mob-tab" data-on={mobSheet === 'media' ? '1' : '0'} onClick={() => setMobSheet('media')}>
          <Icon.image />Media
        </button>
        <button className="mob-tab" data-on={mobSheet === 'fx' ? '1' : '0'} onClick={() => setMobSheet('fx')}>
          <Icon.sparkle />Effects
        </button>
        <button className="mob-tab" data-on={mobSheet === 'insp' ? '1' : '0'} onClick={() => setMobSheet('insp')}>
          <Icon.settings />Inspect
        </button>
      </nav>

      {/* MOBILE SHEETS */}
      <div className="mob-sheet" data-open={mobSheet === 'media' ? '1' : '0'} onClick={() => setMobSheet(null)}>
        <div className="mob-sheet-inner" onClick={(e) => e.stopPropagation()}>
          <div className="mob-sheet-h">
            <div style={{ fontWeight: 600 }}>Media</div>
            <button className="tbtn" onClick={() => setMobSheet(null)}>✕</button>
          </div>
          <div className="media-grid">
            <UploadTile icon={<Icon.upload />} label="Drop / Upload" />
            <UploadTile icon={<Icon.link />} label="Aus URL" />
            {MEDIA.map(m => (
              <MediaTile key={m.id} media={m}
                active={m.id === selectedMedia}
                onClick={() => setSelectedMedia(m.id)} />
            ))}
          </div>
        </div>
      </div>
      <div className="mob-sheet" data-open={mobSheet === 'fx' ? '1' : '0'} onClick={() => setMobSheet(null)}>
        <div className="mob-sheet-inner" onClick={(e) => e.stopPropagation()}>
          <div className="mob-sheet-h">
            <div style={{ fontWeight: 600 }}>Effects</div>
            <button className="tbtn" onClick={() => setMobSheet(null)}>✕</button>
          </div>
          <div className="fx-grid">
            {FX_LIBRARY.map(f => (
              <FxCard key={f.id} fx={f}
                active={f.id === selectedFx}
                onClick={() => setSelectedFx(f.id)} />
            ))}
          </div>
        </div>
      </div>
      <div className="mob-sheet" data-open={mobSheet === 'insp' ? '1' : '0'} onClick={() => setMobSheet(null)}>
        <div className="mob-sheet-inner" onClick={(e) => e.stopPropagation()}>
          <div className="mob-sheet-h">
            <div style={{ fontWeight: 600 }}>Inspector</div>
            <button className="tbtn" onClick={() => setMobSheet(null)}>✕</button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <Inspector selectedClip={currentClip} fx={currentFx} params={params} setParams={setParams} />
          </div>
        </div>
      </div>

      {/* TWEAKS PANEL */}
      <TweaksPanel title="VibeGrid Tweaks">
        <TweakSection label="Theme" />
        <TweakColor label="Accent" value={t.accent}
          options={[
            ['#a86bff', '#5a8fff', '#2ee0d0'],
            ['#ff8a3d', '#ff5fa2', '#b15aff'],
            ['#b6ff3a', '#ff3aa9', '#2ee5ff'],
            ['#2ee5ff', '#ff3aa9', '#b6ff3a'],
          ]}
          onChange={(v) => {
            // Map palette back to key
            const map = {
              '["#a86bff","#5a8fff","#2ee0d0"]': 'electric',
              '["#ff8a3d","#ff5fa2","#b15aff"]': 'sunset',
              '["#b6ff3a","#ff3aa9","#2ee5ff"]': 'acid',
              '["#2ee5ff","#ff3aa9","#b6ff3a"]': 'neon',
            };
            setTweak('accent', map[JSON.stringify(v)] || 'electric');
          }} />
        <TweakSelect label="Font" value={t.font}
          options={[
            { value: 'grotesk', label: 'Space Grotesk' },
            { value: 'tight',   label: 'Inter Tight' },
            { value: 'geist',   label: 'Geist' },
            { value: 'mono',    label: 'JetBrains Mono' },
          ]}
          onChange={(v) => setTweak('font', v)} />
        <TweakRadio label="Style" value={t.style}
          options={['clean', 'balanced', 'expressive']}
          onChange={(v) => setTweak('style', v)} />

        <TweakSection label="Layout" />
        <TweakRadio label="Density" value={t.density}
          options={['compact', 'regular', 'comfy']}
          onChange={(v) => setTweak('density', v)} />
        <TweakRadio label="Timeline" value={t.timeline}
          options={['compact', 'regular', 'tall']}
          onChange={(v) => setTweak('timeline', v)} />
      </TweaksPanel>
    </div>
  );
}

function beatsToTime(beats, bpm) {
  const ms = (beats * 60000) / bpm;
  const total = ms / 1000;
  const m = Math.floor(total / 60);
  const s = Math.floor(total % 60);
  const cs = Math.floor((total * 100) % 100);
  return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}.${String(cs).padStart(2,'0')}`;
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
