// PicTune — Icon set (inline SVGs, currentColor strokes)
// Tiny, geometric — no hand-drawn complexity.

const Icon = {
  play: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <path d="M4 3.2v9.6c0 .9 1 1.4 1.7.9l7.2-4.8a1.1 1.1 0 0 0 0-1.8L5.7 2.3A1.1 1.1 0 0 0 4 3.2z"/>
    </svg>
  ),
  pause: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <rect x="4" y="3" width="3" height="10" rx="1"/>
      <rect x="9" y="3" width="3" height="10" rx="1"/>
    </svg>
  ),
  skipBack: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <rect x="3" y="3" width="2" height="10" rx="0.5"/>
      <path d="M13 3.2v9.6c0 .9-1 1.4-1.7.9L6.1 9.7a1.1 1.1 0 0 1 0-1.8l5.2-4a1.1 1.1 0 0 1 1.7.9z"/>
    </svg>
  ),
  skipFwd: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <rect x="11" y="3" width="2" height="10" rx="0.5"/>
      <path d="M3 3.2v9.6c0 .9 1 1.4 1.7.9l5.2-4a1.1 1.1 0 0 0 0-1.8l-5.2-4A1.1 1.1 0 0 0 3 3.2z"/>
    </svg>
  ),
  upload: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M8 11V3"/>
      <path d="M5 6l3-3 3 3"/>
      <path d="M3 13h10"/>
    </svg>
  ),
  download: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M8 3v8"/>
      <path d="M5 8l3 3 3-3"/>
      <path d="M3 13h10"/>
    </svg>
  ),
  link: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" {...p}>
      <path d="M7 9a3 3 0 0 0 4 0l2-2a3 3 0 0 0-4-4L8 4"/>
      <path d="M9 7a3 3 0 0 0-4 0L3 9a3 3 0 0 0 4 4l1-1"/>
    </svg>
  ),
  image: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <rect x="2" y="3" width="12" height="10" rx="1.5"/>
      <circle cx="6" cy="7" r="1.2" fill="currentColor"/>
      <path d="M3 11l3-3 3 3 2-2 2 2v2H3z" fill="currentColor"/>
    </svg>
  ),
  bolt: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <path d="M9.4 1.6L3.5 9.2h4.1l-1 5.2 5.9-7.6H8.4z"/>
    </svg>
  ),
  circles: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3" {...p}>
      <circle cx="6" cy="7" r="3.4"/>
      <circle cx="10" cy="9" r="3.4"/>
    </svg>
  ),
  particles: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <circle cx="3" cy="12" r="1"/>
      <circle cx="7" cy="9" r="1.5"/>
      <circle cx="11" cy="5" r="1"/>
      <circle cx="5" cy="5" r="0.8"/>
      <circle cx="13" cy="11" r="0.8"/>
      <circle cx="9" cy="13" r="0.6"/>
    </svg>
  ),
  pulse: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M2 8h3l1-3 2 6 2-5 1 2h3"/>
    </svg>
  ),
  glitch: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M3 5h6M7 8h6M3 11h7"/>
    </svg>
  ),
  sparkle: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <path d="M8 1.5l1.2 3.6L13 6l-3.8.9L8 10.5l-1.2-3.6L3 6l3.8-.9z"/>
      <circle cx="13" cy="12" r="1"/>
    </svg>
  ),
  music: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M6 12V3l7-1v9"/>
      <circle cx="4.5" cy="12" r="1.5" fill="currentColor"/>
      <circle cx="11.5" cy="11" r="1.5" fill="currentColor"/>
    </svg>
  ),
  layers: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" {...p}>
      <path d="M8 2L2 5l6 3 6-3z"/>
      <path d="M2 8l6 3 6-3"/>
      <path d="M2 11l6 3 6-3"/>
    </svg>
  ),
  settings: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3" {...p}>
      <circle cx="8" cy="8" r="2"/>
      <path d="M8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.4 1.4M11.6 11.6L13 13M3 13l1.4-1.4M11.6 4.4L13 3"/>
    </svg>
  ),
  plus: (p) => (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" {...p}>
      <path d="M6 2v8M2 6h8"/>
    </svg>
  ),
  scissors: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.3" {...p}>
      <circle cx="4" cy="11" r="2"/>
      <circle cx="12" cy="11" r="2"/>
      <path d="M5.5 9.5L13 3M10.5 9.5L3 3"/>
    </svg>
  ),
  magnet: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" {...p}>
      <path d="M3 3v6a5 5 0 0 0 10 0V3h-3v6a2 2 0 0 1-4 0V3z"/>
    </svg>
  ),
  zoomIn: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" {...p}>
      <circle cx="7" cy="7" r="4"/>
      <path d="M10 10l3 3M5 7h4M7 5v4"/>
    </svg>
  ),
  zoomOut: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" {...p}>
      <circle cx="7" cy="7" r="4"/>
      <path d="M10 10l3 3M5 7h4"/>
    </svg>
  ),
  chevron: (p) => (
    <svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <path d="M3 4l2 2 2-2"/>
    </svg>
  ),
  trash: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" {...p}>
      <path d="M3 4h10M6 4V2.5h4V4M5 4l.5 9h5L11 4"/>
    </svg>
  ),
  fitScreen: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" {...p}>
      <path d="M3 6V3h3M13 6V3h-3M3 10v3h3M13 10v3h-3"/>
    </svg>
  ),
  user: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor" {...p}>
      <circle cx="8" cy="6" r="2.5"/>
      <path d="M3 14a5 5 0 0 1 10 0z"/>
    </svg>
  ),
  share: (p) => (
    <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" {...p}>
      <circle cx="4" cy="8" r="2"/>
      <circle cx="12" cy="4" r="2"/>
      <circle cx="12" cy="12" r="2"/>
      <path d="M5.7 7l4.6-2M5.7 9l4.6 2"/>
    </svg>
  ),
};

window.Icon = Icon;
