// PicTune — Left + Right panels (Media library, FX library, Inspector)

function MediaTile({ media, active, onClick }) {
  return (
    <button className="media-tile" data-active={active ? '1' : '0'} onClick={onClick}>
      <div className="bg" style={{ background: media.grad }}>
        <div style={{
          position: 'absolute', inset: 0,
          background: 'repeating-linear-gradient(135deg, transparent 0, transparent 8px, rgba(255,255,255,0.04) 8px, rgba(255,255,255,0.04) 9px)',
        }} />
      </div>
      <div className="badge"><Icon.image /></div>
      <div className="label">{media.name}</div>
    </button>
  );
}

function UploadTile({ icon, label }) {
  return (
    <button className="media-tile upload">
      {icon}
      <div style={{ fontFamily: 'var(--font-sans)', fontSize: 11, fontWeight: 500 }}>{label}</div>
    </button>
  );
}

function FxThumb({ kind }) {
  // Mini animated previews per fx kind.
  if (kind === 'contour') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle at 50% 60%, rgba(168,107,255,0.35), transparent 70%)',
      }}>
        <svg viewBox="0 0 80 50" style={{ position: 'absolute', inset: 0, width: '100%', height: '100%' }}>
          <path d="M30 8 Q40 4 50 8 Q56 18 50 26 Q60 32 64 44 L16 44 Q20 32 30 26 Q24 18 30 8 Z"
            fill="none" stroke="#a86bff" strokeWidth="1.2"
            style={{ filter: 'drop-shadow(0 0 4px #a86bff)' }} />
        </svg>
      </div>
    );
  }
  if (kind === 'pulse') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle at 50% 50%, rgba(255,95,162,0.4), transparent 60%)',
      }}>
        <div style={{
          position: 'absolute', left: '50%', top: '50%',
          width: 24, height: 24,
          transform: 'translate(-50%, -50%)',
          borderRadius: '50%',
          background: 'linear-gradient(180deg, #ff5fa2, #ff3aa9)',
          boxShadow: '0 0 14px #ff5fa2',
        }} />
        <div style={{
          position: 'absolute', left: '50%', top: '50%',
          width: 40, height: 40,
          transform: 'translate(-50%, -50%)',
          borderRadius: '50%',
          border: '1px solid rgba(255,95,162,0.4)',
        }} />
      </div>
    );
  }
  if (kind === 'sweep') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: '#0f1428',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', width: '70%', height: '120%',
          left: '-10%', top: '-10%',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(168,107,255,0.55), transparent 70%)',
          filter: 'blur(12px)',
        }} />
        <div style={{
          position: 'absolute', width: '60%', height: '120%',
          right: '-5%', top: '20%',
          borderRadius: '50%',
          background: 'radial-gradient(circle, rgba(46,224,208,0.5), transparent 70%)',
          filter: 'blur(14px)',
        }} />
      </div>
    );
  }
  if (kind === 'particles') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(ellipse at 50% 100%, rgba(168,107,255,0.25), transparent 60%)',
      }}>
        {[...Array(14)].map((_, i) => {
          const colors = ['#a86bff', '#5a8fff', '#2ee0d0'];
          const c = colors[i % 3];
          return (
            <i key={i} style={{
              position: 'absolute',
              left: (((i * 37) % 100)) + '%',
              top:  ((20 + (i * 13) % 70)) + '%',
              width: 3, height: 3,
              borderRadius: '50%',
              background: c,
              boxShadow: `0 0 5px ${c}`,
            }} />
          );
        })}
      </div>
    );
  }
  if (kind === 'glitch') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, #2a4dff 0%, #0f1428 100%)',
      }}>
        <div style={{
          position: 'absolute', top: '30%', left: 0, right: 0,
          height: 4, background: 'rgba(255,95,162,0.6)',
          mixBlendMode: 'screen',
        }} />
        <div style={{
          position: 'absolute', top: '60%', left: '-4px', right: 0,
          height: 6, background: 'rgba(46,229,255,0.6)',
          mixBlendMode: 'screen',
        }} />
      </div>
    );
  }
  if (kind === 'shake') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'radial-gradient(circle at 50% 50%, rgba(255,95,162,0.3), transparent 70%)',
      }}>
        <div style={{
          position: 'absolute', left: '40%', top: '30%',
          width: 24, height: 24, borderRadius: 4,
          background: 'linear-gradient(135deg, #a86bff, #5a8fff)',
          boxShadow: '4px 0 0 rgba(255,95,162,0.4), -4px 0 0 rgba(46,229,255,0.4)',
        }} />
      </div>
    );
  }
  if (kind === 'flare') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: '#0f1428',
        overflow: 'hidden',
      }}>
        <div style={{
          position: 'absolute', top: '20%', left: '-20%',
          width: '160%', height: 18,
          background: 'linear-gradient(90deg, transparent 0%, rgba(255,255,255,0.8) 50%, transparent 100%)',
          transform: 'rotate(-15deg)',
          filter: 'blur(2px)',
        }} />
        <div style={{
          position: 'absolute', top: '60%', left: '20%',
          width: 16, height: 16, borderRadius: '50%',
          background: '#fff', filter: 'blur(4px)',
        }} />
      </div>
    );
  }
  if (kind === 'sparkle') {
    return (
      <div style={{
        position: 'absolute', inset: 0,
        background: 'linear-gradient(180deg, #1c1633, #0a0f1f)',
      }}>
        {[...Array(8)].map((_, i) => (
          <div key={i} style={{
            position: 'absolute',
            left: (((i * 23) % 90) + 5) + '%',
            top:  (((i * 31) % 80) + 10) + '%',
            width: 2 + (i % 3), height: 2 + (i % 3),
            background: '#fff',
            borderRadius: '50%',
            boxShadow: '0 0 6px #fff',
          }} />
        ))}
      </div>
    );
  }
  return null;
}

function FxCard({ fx, active, onClick }) {
  return (
    <button className="fx-card" data-active={active ? '1' : '0'} onClick={onClick}>
      <div className="fx-thumb"><FxThumb kind={fx.id} /></div>
      <div className="fx-meta">
        <div className="fx-name">{fx.name}</div>
        <div className="fx-kind">{fx.desc}</div>
      </div>
    </button>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Left panel — switchable Media / FX
function LeftPanel({ tab, setTab, selectedMedia, setSelectedMedia, selectedFx, setSelectedFx }) {
  return (
    <aside className="rail">
      <div className="rail-tabs">
        <button className="rail-tab" data-active={tab === 'media' ? '1' : '0'} onClick={() => setTab('media')}>
          <Icon.image /> Media
        </button>
        <button className="rail-tab" data-active={tab === 'fx' ? '1' : '0'} onClick={() => setTab('fx')}>
          <Icon.sparkle /> Effects
        </button>
        <button className="rail-tab" data-active={tab === 'layers' ? '1' : '0'} onClick={() => setTab('layers')}>
          <Icon.layers /> Layers
        </button>
      </div>
      <div className="rail-body">
        {tab === 'media' && (
          <>
            <div className="rail-section-h">
              <span>Import</span>
            </div>
            <div className="media-grid">
              <UploadTile icon={<Icon.upload />} label="Drop / Upload" />
              <UploadTile icon={<Icon.link />}   label="Aus URL" />
            </div>
            <div className="rail-section-h">
              <span>Mediathek · {MEDIA.length}</span>
              <button className="add"><Icon.plus /></button>
            </div>
            <div className="media-grid">
              {MEDIA.map(m => (
                <MediaTile key={m.id} media={m}
                  active={m.id === selectedMedia}
                  onClick={() => setSelectedMedia(m.id)} />
              ))}
            </div>
          </>
        )}

        {tab === 'fx' && (
          <>
            <div className="rail-section-h">
              <span>Beat-Sync</span>
              <button className="add"><Icon.plus /></button>
            </div>
            <div className="fx-grid">
              {FX_LIBRARY.filter(f => f.defaults.sync === 'beat').map(f => (
                <FxCard key={f.id} fx={f}
                  active={f.id === selectedFx}
                  onClick={() => setSelectedFx(f.id)} />
              ))}
            </div>
            <div className="rail-section-h"><span>Bar-Sync</span></div>
            <div className="fx-grid">
              {FX_LIBRARY.filter(f => f.defaults.sync === 'bar').map(f => (
                <FxCard key={f.id} fx={f}
                  active={f.id === selectedFx}
                  onClick={() => setSelectedFx(f.id)} />
              ))}
            </div>
          </>
        )}

        {tab === 'layers' && (
          <LayersList />
        )}
      </div>
    </aside>
  );
}

function LayersList() {
  return (
    <>
      <div className="rail-section-h"><span>Tracks · {TRACKS.length}</span></div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        {TRACKS.map(t => {
          const I = Icon[t.icon];
          return (
            <div key={t.id} style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '8px 10px',
              background: 'var(--surface-2)',
              border: '1px solid var(--border)',
              borderRadius: 8,
              fontSize: 12,
            }}>
              <span style={{
                width: 22, height: 22, borderRadius: 5,
                background: 'var(--surface-3)',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                color: 'var(--a-primary)',
              }}><I /></span>
              <span style={{ flex: 1, color: 'var(--text)' }}>{t.name}</span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: 10, color: 'var(--text-muted)' }}>
                {INITIAL_CLIPS.filter(c => c.track === t.id).length} clips
              </span>
            </div>
          );
        })}
      </div>
    </>
  );
}

// ─────────────────────────────────────────────────────────────────────────
// Right panel — Inspector
function Inspector({ selectedClip, fx, params, setParams }) {
  if (!fx) {
    return (
      <aside className="rail right">
        <div className="rail-tabs">
          <button className="rail-tab" data-active="1"><Icon.settings /> Inspector</button>
        </div>
        <div className="rail-body" style={{ alignItems: 'center', justifyContent: 'center', textAlign: 'center', color: 'var(--text-muted)' }}>
          <div style={{ fontSize: 12 }}>Wähle einen Clip oder Effekt aus.</div>
        </div>
      </aside>
    );
  }

  const Iicon = Icon[fx.id === 'contour' ? 'bolt' : fx.id === 'sweep' ? 'circles' : fx.id === 'particles' ? 'particles' : fx.id === 'pulse' ? 'pulse' : 'sparkle'];

  return (
    <aside className="rail right">
      <div className="rail-tabs">
        <button className="rail-tab" data-active="1"><Icon.settings /> Inspector</button>
      </div>
      <div className="rail-body">
        <div className="insp-header">
          <span className="insp-icon"><Iicon /></span>
          <div style={{ flex: 1 }}>
            <div className="insp-title">{fx.name}</div>
            <div className="insp-sub">{fx.kind.toLowerCase()} · {fx.defaults.sync}-sync</div>
          </div>
          <button className="tbtn" style={{ color: 'var(--text-muted)' }} title="Remove"><Icon.trash /></button>
        </div>

        <div className="rail-section-h"><span>Trigger</span></div>
        <div className="seg" role="radiogroup">
          {['½ Bar', 'Beat', 'Bar', '2 Bar'].map((l, i) => (
            <button key={l} data-on={i === 1 ? '1' : '0'}>{l}</button>
          ))}
        </div>

        <div className="rail-section-h"><span>Parameters</span></div>

        <div className="prop-row">
          <div className="prop-lbl"><span>Intensity</span><span className="val">{params.intensity}%</span></div>
          <input type="range" className="range" min="0" max="100" value={params.intensity}
                 onChange={(e) => setParams({ ...params, intensity: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="prop-lbl"><span>Stroke</span><span className="val">{params.stroke}px</span></div>
          <input type="range" className="range" min="0.5" max="6" step="0.5" value={params.stroke}
                 onChange={(e) => setParams({ ...params, stroke: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="prop-lbl"><span>Glow</span><span className="val">{params.glow}px</span></div>
          <input type="range" className="range" min="0" max="40" value={params.glow}
                 onChange={(e) => setParams({ ...params, glow: +e.target.value })} />
        </div>

        <div className="prop-row">
          <div className="prop-lbl"><span>Decay</span><span className="val">{params.decay}ms</span></div>
          <input type="range" className="range" min="40" max="800" step="20" value={params.decay}
                 onChange={(e) => setParams({ ...params, decay: +e.target.value })} />
        </div>

        <div className="rail-section-h"><span>Color</span></div>
        <div className="color-strip" role="radiogroup">
          {[
            { c: '#a86bff', on: params.color === 'a1' },
            { c: '#5a8fff', on: params.color === 'a2' },
            { c: '#2ee0d0', on: params.color === 'a3' },
            { c: '#ff5fa2', on: params.color === 'a4' },
            { c: '#b6ff3a', on: params.color === 'a5' },
          ].map((s, i) => (
            <button key={i} className="color-dot"
              style={{ background: s.c, color: s.c }}
              data-on={s.on ? '1' : '0'}
              onClick={() => setParams({ ...params, color: ['a1','a2','a3','a4','a5'][i] })} />
          ))}
        </div>

        <div className="rail-section-h"><span>Easing</span></div>
        <div className="seg" role="radiogroup">
          {['Snap', 'Flash', 'Glide', 'Linear'].map((l) => (
            <button key={l} data-on={l.toLowerCase() === params.easing ? '1' : '0'}
              onClick={() => setParams({ ...params, easing: l.toLowerCase() })}>{l}</button>
          ))}
        </div>

        <div className="rail-section-h"><span>Action</span></div>
        <button className="btn primary" style={{ width: '100%', justifyContent: 'center' }}>
          <Icon.sparkle /> Auto-paint to all beats
        </button>
        <button className="btn ghost" style={{ width: '100%', justifyContent: 'center', marginTop: 6 }}>
          <Icon.scissors /> Slice on transients
        </button>
      </div>
    </aside>
  );
}

window.LeftPanel = LeftPanel;
window.Inspector = Inspector;
